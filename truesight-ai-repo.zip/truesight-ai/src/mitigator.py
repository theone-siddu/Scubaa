"""
mitigator.py
Applies bias mitigation using:
  - AIF360 Reweighing (pre-processing)
  - Fairlearn ThresholdOptimizer (post-processing)
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from aif360.datasets import BinaryLabelDataset
from aif360.algorithms.preprocessing import Reweighing

from fairlearn.postprocessing import ThresholdOptimizer
from fairlearn.metrics import demographic_parity_difference, equalized_odds_difference


def encode_features(df: pd.DataFrame) -> pd.DataFrame:
    df_enc = df.copy()
    le = LabelEncoder()
    for col in ["gender", "zip_code"]:
        if col in df_enc.columns:
            df_enc[col] = le.fit_transform(df_enc[col])
    return df_enc


# ── Pre-processing: AIF360 Reweighing ────────────────────────────────────────

def apply_reweighing(df: pd.DataFrame):
    """
    Reweigh training samples to reduce discrimination before model training.
    Returns: (fair_model, X_test, y_test, y_pred_fair, sample_weights)
    """
    df_enc = encode_features(df)
    feature_cols = ["age", "gender", "zip_code", "credit_score"]

    aif_ds = BinaryLabelDataset(
        df=df_enc[feature_cols + ["approved"]],
        label_names=["approved"],
        protected_attribute_names=["gender"],
    )

    idx = int(len(df_enc) * 0.7)
    ds_train = BinaryLabelDataset(
        df=df_enc.iloc[:idx][feature_cols + ["approved"]],
        label_names=["approved"],
        protected_attribute_names=["gender"],
    )
    ds_test = BinaryLabelDataset(
        df=df_enc.iloc[idx:][feature_cols + ["approved"]],
        label_names=["approved"],
        protected_attribute_names=["gender"],
    )

    # Apply Reweighing
    rw = Reweighing(
        unprivileged_groups=[{"gender": 0}],
        privileged_groups=[{"gender": 1}],
    )
    ds_train_rw = rw.fit_transform(ds_train)

    # Train fair model
    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(
        ds_train_rw.features,
        ds_train_rw.labels.ravel(),
        sample_weight=ds_train_rw.instance_weights,
    )

    X_test = pd.DataFrame(ds_test.features, columns=feature_cols)
    y_test = ds_test.labels.ravel()
    y_pred = model.predict(X_test)

    return model, X_test, y_test, y_pred


# ── Post-processing: Fairlearn ThresholdOptimizer ────────────────────────────

def apply_threshold_optimizer(df: pd.DataFrame):
    """
    Adjust decision thresholds post-training to satisfy Equalized Odds.
    Returns: (X_test, y_test, y_pred_fair, sensitive_test)
    """
    df_enc = encode_features(df)
    feature_cols = ["age", "gender", "zip_code", "credit_score"]

    X = df_enc[feature_cols]
    y = df_enc["approved"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    # Train base model
    base_model = LogisticRegression(max_iter=1000, random_state=42)
    base_model.fit(X_train, y_train)

    # ThresholdOptimizer
    postproc = ThresholdOptimizer(
        estimator=base_model,
        constraints="equalized_odds",
        predict_method="predict_proba",
        objective="balanced_accuracy_score",
    )
    postproc.fit(X_train, y_train, sensitive_features=X_train["gender"])

    y_pred_fair = postproc.predict(X_test, sensitive_features=X_test["gender"])

    gender_map = {0: "Female", 1: "Male"}
    sensitive_test = X_test["gender"].map(gender_map)

    return X_test, y_test, y_pred_fair, sensitive_test


# ── Combined mitigation metrics ───────────────────────────────────────────────

def compute_post_mitigation_metrics(y_test, y_pred_fair, sensitive_features) -> dict:
    """Compute fairness metrics after mitigation for before/after comparison."""
    dpd = demographic_parity_difference(
        y_test, y_pred_fair, sensitive_features=sensitive_features
    )
    eod = equalized_odds_difference(
        y_test, y_pred_fair, sensitive_features=sensitive_features
    )
    return {
        "demographic_parity_difference_after": round(float(dpd), 4),
        "equalized_odds_difference_after":     round(float(eod), 4),
    }


if __name__ == "__main__":
    import sys
    sys.path.append(".")
    from data_generator import generate_biased_dataset

    df = generate_biased_dataset()

    print("\n── Reweighing mitigation ──")
    _, X_test, y_test, y_pred = apply_reweighing(df)
    gender_map = {0: "Female", 1: "Male"}
    sens = X_test["gender"].map(gender_map)
    metrics = compute_post_mitigation_metrics(y_test, y_pred, sens)
    print(metrics)

    print("\n── ThresholdOptimizer mitigation ──")
    X_test2, y_test2, y_pred2, sens2 = apply_threshold_optimizer(df)
    metrics2 = compute_post_mitigation_metrics(y_test2, y_pred2, sens2)
    print(metrics2)
