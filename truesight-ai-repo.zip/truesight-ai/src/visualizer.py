"""
visualizer.py
Generates before/after bias comparison charts.
Outputs matplotlib figures (saved as PNG or shown inline in Colab).
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import numpy as np
import os


COLORS = {
    "biased":   "#DC2626",   # red
    "fair":     "#16A34A",   # green
    "neutral":  "#2563EB",   # blue
    "bg":       "#F8FAFC",
    "text":     "#1E293B",
}


def plot_bias_comparison(before: dict, after: dict, save_path: str = None):
    """
    Side-by-side bar chart comparing key fairness metrics before and after mitigation.
    """
    metrics_labels = {
        "demographic_parity_difference": "Demographic\nParity Diff",
        "equalized_odds_difference":     "Equalized\nOdds Diff",
    }

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.patch.set_facecolor(COLORS["bg"])
    fig.suptitle(
        "TrueSight AI — Bias Mitigation Results",
        fontsize=16, fontweight="bold", color=COLORS["text"], y=1.02
    )

    for ax, (key, label) in zip(axes, metrics_labels.items()):
        before_val = abs(before.get(key, 0))
        after_key  = key + "_after"
        after_val  = abs(after.get(after_key, after.get(key, 0)))

        bars = ax.bar(
            ["Before\nMitigation", "After\nMitigation"],
            [before_val, after_val],
            color=[COLORS["biased"], COLORS["fair"]],
            width=0.45,
            edgecolor="white",
            linewidth=1.5,
        )

        # Threshold line
        ax.axhline(y=0.10, color="#F59E0B", linestyle="--", linewidth=1.5,
                   label="Acceptable threshold (0.10)")

        # Value labels on bars
        for bar, val in zip(bars, [before_val, after_val]):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{val:.3f}",
                ha="center", va="bottom", fontsize=13, fontweight="bold",
                color=COLORS["text"]
            )

        ax.set_title(label, fontsize=13, fontweight="bold", color=COLORS["text"])
        ax.set_ylim(0, max(before_val * 1.4, 0.30))
        ax.set_facecolor(COLORS["bg"])
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(fontsize=9)

    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"✅ Chart saved to {save_path}")

    return fig


def plot_price_distribution(df, save_path: str = None):
    """
    KDE plot showing price distribution by gender — visually demonstrates bias.
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["bg"])

    for gender, color in [("Male", COLORS["neutral"]), ("Female", COLORS["biased"])]:
        subset = df[df["gender"] == gender]["final_price"]
        sns.kdeplot(subset, ax=ax, fill=True, alpha=0.35, color=color, label=gender)
        ax.axvline(subset.mean(), color=color, linestyle="--", linewidth=1.5,
                   label=f"{gender} mean: ${subset.mean():.1f}")

    ax.set_title(
        "Price Distribution by Gender — Injected Bias Visible",
        fontsize=14, fontweight="bold", color=COLORS["text"]
    )
    ax.set_xlabel("Final Price ($)", fontsize=12)
    ax.set_ylabel("Density", fontsize=12)
    ax.legend(fontsize=10)
    ax.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"✅ Chart saved to {save_path}")

    return fig


def plot_disparate_impact_gauge(di_before: float, di_after: float, save_path: str = None):
    """
    Horizontal gauge-style chart for Disparate Impact Ratio before/after.
    """
    fig, ax = plt.subplots(figsize=(10, 3))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["bg"])

    ax.barh(["Before", "After"], [di_before, di_after],
            color=[COLORS["biased"], COLORS["fair"]],
            height=0.4, edgecolor="white")

    ax.axvline(x=0.80, color="#F59E0B", linestyle="--", linewidth=2,
               label="Legal threshold (0.80)")
    ax.axvline(x=1.00, color="#94A3B8", linestyle=":", linewidth=1.5,
               label="Perfect parity (1.00)")

    for i, val in enumerate([di_before, di_after]):
        ax.text(val + 0.01, i, f"{val:.3f}", va="center", fontsize=13,
                fontweight="bold", color=COLORS["text"])

    ax.set_xlim(0, 1.3)
    ax.set_title("Disparate Impact Ratio — Before vs After Mitigation",
                 fontsize=13, fontweight="bold", color=COLORS["text"])
    ax.legend(fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


if __name__ == "__main__":
    import sys
    sys.path.append(".")
    from data_generator import generate_biased_dataset

    df = generate_biased_dataset()
    plot_price_distribution(df, save_path="outputs/price_distribution.png")

    before = {"demographic_parity_difference": 0.22, "equalized_odds_difference": 0.19}
    after  = {"demographic_parity_difference_after": 0.04, "equalized_odds_difference_after": 0.03}
    plot_bias_comparison(before, after, save_path="outputs/bias_comparison.png")

    plot_disparate_impact_gauge(0.67, 0.88, save_path="outputs/di_gauge.png")
    plt.show()
