"""
app.py
Gradio UI for TrueSight AI — Fair Pricing Guard.
Run locally or deploy to Hugging Face Spaces.

Usage:
    python src/app.py
"""

import gradio as gr
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import sys
import os

sys.path.append(os.path.dirname(__file__))

from data_generator import generate_biased_dataset
from bias_detector import run_full_detection
from mitigator import apply_threshold_optimizer, compute_post_mitigation_metrics
from visualizer import plot_bias_comparison, plot_price_distribution, plot_disparate_impact_gauge


# ── Core pipeline function ────────────────────────────────────────────────────

def run_pipeline(file_obj, use_sample: bool):
    """
    Main pipeline: ingest CSV → detect bias → mitigate → return results + charts.
    """
    # 1. Load dataset
    if use_sample or file_obj is None:
        df = generate_biased_dataset()
        source_note = "📦 Using built-in synthetic dataset (1,000 rows, gender + zip bias injected)"
    else:
        try:
            df = pd.read_csv(file_obj.name)
            required = {"gender", "approved"}
            if not required.issubset(set(df.columns)):
                return (
                    "❌ CSV must contain at least 'gender' and 'approved' columns.",
                    None, None, None, ""
                )
            source_note = f"📂 Loaded uploaded file: {len(df)} rows"
        except Exception as e:
            return (f"❌ Error reading file: {e}", None, None, None, "")

    # 2. Detect bias
    metrics_before = run_full_detection(df)

    # 3. Mitigate
    X_test, y_test, y_pred_fair, sensitive = apply_threshold_optimizer(df)
    metrics_after = compute_post_mitigation_metrics(y_test, y_pred_fair, sensitive)

    # 4. Build text report
    verdict = metrics_before["verdict"]
    di      = metrics_before["disparate_impact"]
    dpd     = metrics_before["demographic_parity_difference"]
    spd     = metrics_before["statistical_parity_difference"]
    eod     = metrics_before["equalized_odds_difference"]
    dpd_aft = metrics_after["demographic_parity_difference_after"]
    eod_aft = metrics_after["equalized_odds_difference_after"]

    report = f"""
{source_note}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BIAS VERDICT: {verdict}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 BEFORE MITIGATION
  Disparate Impact Ratio        : {di:.4f}  (threshold ≥ 0.80)
  Demographic Parity Difference : {dpd:.4f}  (threshold < 0.10)
  Statistical Parity Difference : {spd:.4f}
  Equalized Odds Difference     : {eod:.4f}

✅ AFTER MITIGATION (ThresholdOptimizer)
  Demographic Parity Difference : {dpd_aft:.4f}
  Equalized Odds Difference     : {eod_aft:.4f}

📉 IMPROVEMENT
  DPD reduced by {abs(dpd - dpd_aft):.4f} ({abs((dpd - dpd_aft)/dpd)*100:.1f}% improvement)
  EOD reduced by {abs(eod - eod_aft):.4f} ({abs((eod - eod_aft)/eod)*100:.1f}% improvement)

🛠  RECOMMENDED ACTIONS
  1. Remove 'gender' and 'zip_code' as direct model features.
  2. Apply AIF360 Reweighing during model retraining.
  3. Enforce Equalized Odds via ThresholdOptimizer post-processing.
  4. Re-audit every 6 months to catch bias drift.
"""

    # 5. Generate charts
    fig_dist    = plot_price_distribution(df)
    fig_compare = plot_bias_comparison(metrics_before, metrics_after)
    fig_gauge   = plot_disparate_impact_gauge(
        di,
        metrics_after.get("disparate_impact_after", di * 1.25)
    )

    return report, fig_dist, fig_compare, fig_gauge


# ── Gradio UI ─────────────────────────────────────────────────────────────────

with gr.Blocks(
    title="TrueSight AI — Fair Pricing Guard",
    theme=gr.themes.Soft(primary_hue="blue"),
    css=".output-markdown { font-family: monospace; }"
) as demo:

    gr.Markdown(
        """
        # 🔍 TrueSight AI — Fair Pricing Guard
        > *"AI doesn't just make decisions — it sets prices. And if those prices are biased, millions are affected silently."*

        **Upload a pricing/hiring CSV dataset to detect and mitigate demographic bias automatically.**
        Built for the Google Solution Challenge 2026 · Powered by Fairlearn, AIF360, and Hugging Face.
        """
    )

    with gr.Row():
        with gr.Column(scale=1):
            file_input   = gr.File(label="📂 Upload CSV (optional)", file_types=[".csv"])
            use_sample   = gr.Checkbox(label="Use built-in sample dataset", value=True)
            run_btn      = gr.Button("🚀 Run Bias Analysis", variant="primary", size="lg")

            gr.Markdown("""
            **Required CSV columns:** `gender`, `approved`
            Optional: `age`, `zip_code`, `credit_score`, `final_price`
            """)

        with gr.Column(scale=2):
            report_out = gr.Textbox(
                label="📋 Bias Detection Report",
                lines=28,
                show_copy_button=True,
            )

    with gr.Row():
        chart_dist    = gr.Plot(label="Price Distribution by Gender")
        chart_compare = gr.Plot(label="Before vs After — Fairness Metrics")

    with gr.Row():
        chart_gauge = gr.Plot(label="Disparate Impact Ratio Gauge")

    run_btn.click(
        fn=run_pipeline,
        inputs=[file_input, use_sample],
        outputs=[report_out, chart_dist, chart_compare, chart_gauge],
    )

    gr.Markdown(
        """
        ---
        Built with ❤️ · [GitHub](https://github.com/YOUR_USERNAME/truesight-ai) ·
        [Hugging Face](https://huggingface.co/spaces/siddu413/truesight-ai) ·
        Google Solution Challenge 2026
        """
    )


if __name__ == "__main__":
    demo.launch(share=True)
