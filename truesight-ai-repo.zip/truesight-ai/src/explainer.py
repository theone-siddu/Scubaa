"""
explainer.py
Generates plain-English bias explanations using Hugging Face FLAN-T5.
No API key required — fully open-source.
"""

from transformers import pipeline
import torch


_explainer_pipeline = None  # Lazy-loaded singleton


def _load_pipeline(model_name: str = "google/flan-t5-large"):
    """Load the Hugging Face text2text pipeline (cached after first load)."""
    global _explainer_pipeline
    if _explainer_pipeline is None:
        device = 0 if torch.cuda.is_available() else -1
        print(f"⏳ Loading {model_name} on {'GPU' if device == 0 else 'CPU'}...")
        _explainer_pipeline = pipeline(
            "text2text-generation",
            model=model_name,
            device=device,
        )
        print("✅ Model loaded.")
    return _explainer_pipeline


def build_prompt(metrics: dict) -> str:
    """Build a structured prompt from bias metrics for the LLM."""
    di  = metrics.get("disparate_impact", "N/A")
    dpd = metrics.get("demographic_parity_difference", "N/A")
    spd = metrics.get("statistical_parity_difference", "N/A")
    eod = metrics.get("equalized_odds_difference", "N/A")
    verdict = metrics.get("verdict", "Unknown")

    prompt = (
        f"Explain the following AI bias findings in simple, clear language "
        f"suitable for a policy maker or HR manager. "
        f"Bias verdict: {verdict}. "
        f"Disparate Impact Ratio: {di} (values below 0.8 indicate discrimination by law). "
        f"Demographic Parity Difference: {dpd} (values above 0.1 are concerning). "
        f"Statistical Parity Difference: {spd}. "
        f"Equalized Odds Difference: {eod}. "
        f"Explain what this means for affected groups and suggest what should be done."
    )
    return prompt


def generate_explanation(
    metrics: dict,
    model_name: str = "google/flan-t5-large",
    max_new_tokens: int = 250,
) -> str:
    """
    Generate a plain-English explanation of the bias metrics.

    Args:
        metrics: dict from bias_detector.run_full_detection()
        model_name: Hugging Face model ID
        max_new_tokens: max output length

    Returns:
        Plain-English explanation string
    """
    explainer = _load_pipeline(model_name)
    prompt    = build_prompt(metrics)

    result = explainer(prompt, max_new_tokens=max_new_tokens)[0]["generated_text"]
    return result.strip()


def get_remediation_steps(metrics: dict) -> list[str]:
    """Return concrete remediation recommendations based on metric severity."""
    steps = []
    di  = metrics.get("disparate_impact", 1.0)
    dpd = abs(metrics.get("demographic_parity_difference", 0.0))

    if di < 0.80 or dpd > 0.10:
        steps.append(
            "1. Remove or anonymize protected demographic features (gender, zip code) "
            "from the model's input features."
        )
        steps.append(
            "2. Apply AIF360 Reweighing to retrain the model with rebalanced sample "
            "weights that reduce group disparities."
        )
        steps.append(
            "3. Apply Fairlearn ThresholdOptimizer post-processing to enforce "
            "Equalized Odds constraints on model outputs."
        )
        steps.append(
            "4. Re-audit the model every 6 months using this pipeline to catch "
            "bias drift as new data is collected."
        )
    else:
        steps.append(
            "✅ Model is within acceptable fairness thresholds. "
            "Continue monitoring quarterly."
        )

    return steps


if __name__ == "__main__":
    # Standalone test with mock metrics
    mock_metrics = {
        "disparate_impact":              0.67,
        "demographic_parity_difference": 0.21,
        "statistical_parity_difference": -0.19,
        "equalized_odds_difference":     0.18,
        "verdict":                       "🔴 SEVERELY BIASED",
    }

    print("\n===== AI EXPLANATION =====")
    explanation = generate_explanation(mock_metrics)
    print(explanation)

    print("\n===== REMEDIATION STEPS =====")
    for step in get_remediation_steps(mock_metrics):
        print(step)
