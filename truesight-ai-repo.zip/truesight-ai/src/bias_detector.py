"""
bias_detector.py
Computes fairness metrics using Fairlearn and AIF360.
Returns a structured dict of all bias scores.
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from fairlearn.metrics import (
    MetricFrame,
    demographic_parity_difference,
    equalized_odds_difference,
)
from sklearn.metrics import accuracy_score

from aif360.datasets import BinaryLabelDataset
from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric
from aif360.algorithms.preprocessing import Reweighing


def encode_features(df: pd.DataFrame):
    """Label-encode categorical columns for model training."""
    df_enc = df.copy()
    le = LabelEncoder()
    for col in ["gender", "zip_code"]:
        if col in df_enc.columns:
            df_enc[col] = le.fit_transform(df_enc[col])
    return df_enc


def train_baseline_model(df: pd.DataFrame):
    """Train a simple logistic regression model on the biased dataset."""
    df_enc = encode_features(df)

    feature_cols = ["age", "gender", "zip_code", "credit_score"]
    X = df_enc[feature_cols]
    y = df_enc["approved"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    return model, X_train, X_test, y_train, y_test, y_pred


def compute_fairlearn_metrics(y_test, y_pred, sensitive_features) -> dict:
    """Compute Fairlearn fairness metrics."""
    mf = MetricFrame(
        metrics=accuracy_score,
        y_true=y_test,
        y_pred=y_pred,
        sensitive_features=sensitive_features,
    )

    dpd = demographic_parity_difference(
        y_test, y_pred, sensitive_features=sensitive_features
    )
    eod = equalized_odds_difference(
        y_test, y_pred, sensitive_features=sensitive_features
    )

    return {
        "overall_accuracy":              round(float(mf.overall), 4),
        "accuracy_by_group":             mf.by_group.to_dict(),
        "demographic_parity_difference": round(float(dpd), 4),
        "equalized_odds_difference":     round(float(eod), 4),
    }


def compute_aif360_metrics(df: pd.DataFrame) -> dict:
    """Compute AIF360 fairness metrics (Disparate Impact, Statistical Parity)."""
    df_enc = encode_features(df)

    aif_ds = BinaryLabelDataset(
        df=df_enc[["gender", "zip_code", "age", "credit_score", "approved"]],
        label_names=["approved"],
        protected_attribute_names=["gender"],
    )

    metric = BinaryLabelDatasetMetric(
        aif_ds,
        unprivileged_groups=[{"gender": 0}],   # Female = 0 after LabelEncoder
        privileged_groups=[{"gender": 1}],      # Male   = 1
    )

    return {
        "disparate_impact":             round(float(metric.disparate_impact()), 4),
        "statistical_parity_difference":round(float(metric.statistical_parity_difference()), 4),
        "num_positives_unprivileged":   int(metric.num_positives(privileged=False)),
        "num_positives_privileged":     int(metric.num_positives(privileged=True)),
    }


def get_bias_verdict(metrics: dict) -> str:
    """Return a human-readable bias verdict based on metric thresholds."""
    di  = metrics.get("disparate_impact", 1.0)
    dpd = abs(metrics.get("demographic_parity_difference", 0.0))

    if di < 0.60 or dpd > 0.20:
        return "🔴 SEVERELY BIASED"
    elif di < 0.80 or dpd > 0.10:
        return "🟠 BIASED (below legal threshold)"
    elif di < 0.90 or dpd > 0.05:
        return "🟡 MODERATE BIAS"
    else:
        return "🟢 FAIR"


def run_full_detection(df: pd.DataFrame) -> dict:
    """
    Run the full bias detection pipeline.
    Returns a combined dict of all metrics + verdict.
    """
    _, _, X_test, _, y_test, y_pred = train_baseline_model(df)

    # Re-map gender back to original strings for readable output
    gender_map   = {0: "Female", 1: "Male"}
    sensitive_ft = X_test["gender"].map(gender_map)

    fl_metrics  = compute_fairlearn_metrics(y_test, y_pred, sensitive_ft)
    aif_metrics = compute_aif360_metrics(df)

    all_metrics = {**fl_metrics, **aif_metrics}
    all_metrics["verdict"] = get_bias_verdict(all_metrics)

    return all_metrics


if __name__ == "__main__":
    from data_generator import generate_biased_dataset

    df = generate_biased_dataset()
    results = run_full_detection(df)

    print("\n===== BIAS DETECTION RESULTS =====")
    for k, v in results.items():
        print(f"  {k}: {v}")
