"""
data_generator.py
Generates a synthetic pricing dataset with injected demographic bias.
Used for demo purposes — shows a dramatic before/after in bias metrics.
"""

import pandas as pd
import numpy as np


def generate_biased_dataset(n: int = 1000, seed: int = 42) -> pd.DataFrame:
    """
    Generate a synthetic insurance/e-commerce pricing dataset
    with intentionally injected gender and zip-code bias.

    Bias injected:
      - Women charged ~18% more than men on average
      - Low-income zip codes charged ~12% more
    """
    np.random.seed(seed)

    age        = np.random.randint(22, 65, n)
    gender     = np.random.choice(["Male", "Female"], n)
    zip_code   = np.random.choice(["affluent", "middle", "low_income"], n,
                                   p=[0.3, 0.4, 0.3])
    credit_score = np.random.randint(580, 800, n)
    base_price   = np.random.uniform(100, 500, n)

    # --- Inject gender bias ---
    gender_multiplier = np.where(gender == "Female", 1.18, 1.0)

    # --- Inject zip-code bias ---
    zip_multiplier = np.where(zip_code == "low_income", 1.12,
                     np.where(zip_code == "middle",     1.05, 1.0))

    final_price = base_price * gender_multiplier * zip_multiplier

    # Binary approval label (biased: women approved less)
    approval_prob = (
        0.70
        - 0.15 * (gender == "Female")
        - 0.10 * (zip_code == "low_income")
        + 0.0005 * (credit_score - 580)
    )
    approved = (np.random.rand(n) < approval_prob).astype(int)

    df = pd.DataFrame({
        "age":          age,
        "gender":       gender,
        "zip_code":     zip_code,
        "credit_score": credit_score,
        "base_price":   base_price.round(2),
        "final_price":  final_price.round(2),
        "approved":     approved,
    })

    return df


def save_sample_csv(path: str = "data/sample_pricing_dataset.csv"):
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df = generate_biased_dataset()
    df.to_csv(path, index=False)
    print(f"✅ Sample dataset saved to {path} ({len(df)} rows)")
    return df


if __name__ == "__main__":
    save_sample_csv()
