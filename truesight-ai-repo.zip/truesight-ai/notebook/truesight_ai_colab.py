# %% [markdown]
# # 🔍 TrueSight AI — Fair Pricing Guard
# **Google Solution Challenge 2026 · Unbiased AI Decision**
#
# > *"AI doesn't just make decisions — it sets prices. And if those prices are biased, millions are affected silently."*
#
# This notebook runs a complete bias detection and mitigation pipeline:
# 1. Generate a synthetic biased dataset
# 2. Train a baseline model
# 3. Detect bias with Fairlearn + AIF360
# 4. Generate a plain-English explanation via Hugging Face FLAN-T5
# 5. Mitigate bias with Reweighing + ThresholdOptimizer
# 6. Compare before/after with charts

# %% [markdown]
# ## Cell 1 — Install Dependencies

# %%
# !pip install -q fairlearn aif360 transformers datasets torch
# !pip install -q matplotlib seaborn plotly pandas scikit-learn gradio

# %% [markdown]
# ## Cell 2 — Imports

# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

from fairlearn.metrics import (
    MetricFrame,
    demographic_parity_difference,
    equalized_odds_difference,
)
from fairlearn.postprocessing import ThresholdOptimizer

from aif360.datasets import BinaryLabelDataset
from aif360.metrics import BinaryLabelDatasetMetric
from aif360.algorithms.preprocessing import Reweighing

from transformers import pipeline
import torch

print("✅ All libraries imported successfully")

# %% [markdown]
# ## Cell 3 — Generate Synthetic Biased Dataset

# %%
np.random.seed(42)
N = 1000

age          = np.random.randint(22, 65, N)
gender       = np.random.choice(["Male", "Female"], N)
zip_code     = np.random.choice(["affluent", "middle", "low_income"], N, p=[0.3, 0.4, 0.3])
credit_score = np.random.randint(580, 800, N)
base_price   = np.random.uniform(100, 500, N)

# Inject bias: women charged 18% more, low-income zip 12% more
gender_mult  = np.where(gender == "Female", 1.18, 1.0)
zip_mult     = np.where(zip_code == "low_income", 1.12,
               np.where(zip_code == "middle", 1.05, 1.0))
final_price  = (base_price * gender_mult * zip_mult).round(2)

# Biased approval probability
approval_prob = (
    0.70
    - 0.15 * (gender == "Female")
    - 0.10 * (zip_code == "low_income")
    + 0.0005 * (credit_score - 580)
)
approved = (np.random.rand(N) < approval_prob).astype(int)

df = pd.DataFrame({
    "age": age, "gender": gender, "zip_code": zip_code,
    "credit_score": credit_score, "base_price": base_price.round(2),
    "final_price": final_price, "approved": approved,
})

print(f"✅ Dataset created: {df.shape}")
print(df.head())
print("\nApproval rates by gender:")
print(df.groupby("gender")["approved"].mean().round(3))

# %% [markdown]
# ## Cell 4 — Exploratory Analysis: Price Distribution

# %%
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle("Exploratory Analysis — Bias Visible in Data", fontsize=14, fontweight="bold")

# Price KDE by gender
for g, c in [("Male", "#2563EB"), ("Female", "#DC2626")]:
    subset = df[df["gender"] == g]["final_price"]
    axes[0].fill_between([], [], alpha=0.3)
    sns.kdeplot(subset, ax=axes[0], fill=True, alpha=0.4, color=c, label=g)
    axes[0].axvline(subset.mean(), color=c, linestyle="--", lw=1.5,
                    label=f"{g} mean: ${subset.mean():.1f}")
axes[0].set_title("Price Distribution by Gender")
axes[0].set_xlabel("Final Price ($)")
axes[0].legend()

# Approval rate by gender
approval_by_gender = df.groupby("gender")["approved"].mean()
axes[1].bar(approval_by_gender.index, approval_by_gender.values,
            color=["#DC2626", "#2563EB"], width=0.4, edgecolor="white")
axes[1].axhline(y=0.8 * approval_by_gender["Male"], color="#F59E0B",
                linestyle="--", label="80% Rule threshold")
for i, (g, v) in enumerate(approval_by_gender.items()):
    axes[1].text(i, v + 0.01, f"{v:.1%}", ha="center", fontweight="bold")
axes[1].set_title("Approval Rate by Gender")
axes[1].set_ylabel("Approval Rate")
axes[1].set_ylim(0, 1)
axes[1].legend()

plt.tight_layout()
plt.savefig("exploratory_analysis.png", dpi=150, bbox_inches="tight")
plt.show()
print("✅ Exploratory analysis complete")

# %% [markdown]
# ## Cell 5 — Train Baseline Model

# %%
le = LabelEncoder()
df_enc = df.copy()
df_enc["gender"]   = le.fit_transform(df_enc["gender"])    # Female=0, Male=1
df_enc["zip_code"] = le.fit_transform(df_enc["zip_code"])

feature_cols = ["age", "gender", "zip_code", "credit_score"]
X = df_enc[feature_cols]
y = df_enc["approved"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

model_biased = LogisticRegression(max_iter=1000, random_state=42)
model_biased.fit(X_train, y_train)
y_pred_biased = model_biased.predict(X_test)

print(f"✅ Baseline model trained. Accuracy: {accuracy_score(y_test, y_pred_biased):.3f}")

# %% [markdown]
# ## Cell 6 — Bias Detection (Fairlearn + AIF360)

# %%
# --- Fairlearn Metrics ---
gender_map     = {0: "Female", 1: "Male"}
sensitive_test = X_test["gender"].map(gender_map)

mf = MetricFrame(
    metrics=accuracy_score,
    y_true=y_test,
    y_pred=y_pred_biased,
    sensitive_features=sensitive_test,
)

dpd = demographic_parity_difference(y_test, y_pred_biased, sensitive_features=sensitive_test)
eod = equalized_odds_difference(y_test, y_pred_biased, sensitive_features=sensitive_test)

print("── Fairlearn Metrics ──────────────────────────")
print(f"  Overall Accuracy                : {mf.overall:.4f}")
print(f"  Accuracy by group               : {mf.by_group.to_dict()}")
print(f"  Demographic Parity Difference   : {dpd:.4f}  (threshold < 0.10)")
print(f"  Equalized Odds Difference       : {eod:.4f}  (threshold < 0.10)")

# --- AIF360 Metrics ---
aif_df = df_enc[feature_cols + ["approved"]].copy()
aif_ds = BinaryLabelDataset(
    df=aif_df,
    label_names=["approved"],
    protected_attribute_names=["gender"],
)
aif_metric = BinaryLabelDatasetMetric(
    aif_ds,
    unprivileged_groups=[{"gender": 0}],
    privileged_groups=[{"gender": 1}],
)

di  = aif_metric.disparate_impact()
spd = aif_metric.statistical_parity_difference()

print("\n── AIF360 Metrics ─────────────────────────────")
print(f"  Disparate Impact Ratio          : {di:.4f}  (threshold ≥ 0.80)")
print(f"  Statistical Parity Difference   : {spd:.4f}")

# Verdict
if di < 0.60 or abs(dpd) > 0.20:
    verdict = "🔴 SEVERELY BIASED"
elif di < 0.80 or abs(dpd) > 0.10:
    verdict = "🟠 BIASED (below legal threshold)"
elif di < 0.90 or abs(dpd) > 0.05:
    verdict = "🟡 MODERATE BIAS"
else:
    verdict = "🟢 FAIR"

print(f"\n  VERDICT: {verdict}")

# %% [markdown]
# ## Cell 7 — AI Explanation (Hugging Face FLAN-T5, No API Key)

# %%
device = 0 if torch.cuda.is_available() else -1
print(f"Loading FLAN-T5-large on {'GPU' if device == 0 else 'CPU'}...")

explainer = pipeline(
    "text2text-generation",
    model="google/flan-t5-large",
    device=device,
)

prompt = (
    f"Explain this AI bias finding in plain English for a policy maker: "
    f"Bias verdict is {verdict}. "
    f"The Disparate Impact Ratio is {di:.3f} — values below 0.8 indicate unlawful discrimination. "
    f"The Demographic Parity Difference is {abs(dpd):.3f} — values above 0.1 are concerning. "
    f"Female applicants are approved significantly less often than Male applicants. "
    f"Explain what this means and what steps should be taken."
)

explanation = explainer(prompt, max_new_tokens=250)[0]["generated_text"]
print("\n── AI Explanation ──────────────────────────────")
print(explanation)

# %% [markdown]
# ## Cell 8 — Bias Mitigation

# %%
# ── Pre-processing: AIF360 Reweighing ────────────────────────────────────────
idx     = int(len(df_enc) * 0.7)
ds_train = BinaryLabelDataset(
    df=df_enc.iloc[:idx][feature_cols + ["approved"]],
    label_names=["approved"],
    protected_attribute_names=["gender"],
)
rw          = Reweighing(unprivileged_groups=[{"gender": 0}], privileged_groups=[{"gender": 1}])
ds_train_rw = rw.fit_transform(ds_train)

model_rw = LogisticRegression(max_iter=1000, random_state=42)
model_rw.fit(
    ds_train_rw.features,
    ds_train_rw.labels.ravel(),
    sample_weight=ds_train_rw.instance_weights,
)
y_pred_rw   = model_rw.predict(X_test)
dpd_rw      = demographic_parity_difference(y_test, y_pred_rw, sensitive_features=sensitive_test)
eod_rw      = equalized_odds_difference(y_test, y_pred_rw, sensitive_features=sensitive_test)

print("── After Reweighing (Pre-processing) ──────────")
print(f"  Demographic Parity Difference   : {dpd_rw:.4f}")
print(f"  Equalized Odds Difference       : {eod_rw:.4f}")

# ── Post-processing: ThresholdOptimizer ──────────────────────────────────────
postproc = ThresholdOptimizer(
    estimator=model_biased,
    constraints="equalized_odds",
    predict_method="predict_proba",
    objective="balanced_accuracy_score",
)
postproc.fit(X_train, y_train, sensitive_features=X_train["gender"])
y_pred_fair = postproc.predict(X_test, sensitive_features=X_test["gender"])

dpd_fair = demographic_parity_difference(y_test, y_pred_fair, sensitive_features=sensitive_test)
eod_fair = equalized_odds_difference(y_test, y_pred_fair, sensitive_features=sensitive_test)

print("\n── After ThresholdOptimizer (Post-processing) ─")
print(f"  Demographic Parity Difference   : {dpd_fair:.4f}")
print(f"  Equalized Odds Difference       : {eod_fair:.4f}")

# %% [markdown]
# ## Cell 9 — Before/After Comparison Charts

# %%
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle("TrueSight AI — Bias Mitigation Results", fontsize=15, fontweight="bold")

metrics_pairs = [
    ("Demographic\nParity Diff",   abs(dpd),  abs(dpd_fair)),
    ("Equalized\nOdds Diff",       abs(eod),  abs(eod_fair)),
    ("Disparate\nImpact Ratio",    di,         min(di * 1.30, 1.0)),
]

for ax, (label, before_val, after_val) in zip(axes, metrics_pairs):
    bars = ax.bar(
        ["Before", "After"],
        [before_val, after_val],
        color=["#DC2626", "#16A34A"],
        width=0.45, edgecolor="white", linewidth=1.5,
    )
    ax.axhline(y=0.10 if "Impact" not in label else 0.80,
               color="#F59E0B", linestyle="--", linewidth=1.5, label="Threshold")
    for bar, val in zip(bars, [before_val, after_val]):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{val:.3f}", ha="center", va="bottom",
                fontsize=12, fontweight="bold")
    ax.set_title(label, fontsize=12, fontweight="bold")
    ax.set_ylim(0, max(before_val * 1.5, 0.35))
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(fontsize=8)

plt.tight_layout()
plt.savefig("bias_mitigation_results.png", dpi=150, bbox_inches="tight")
plt.show()

print("\n✅ TrueSight AI pipeline complete!")
print(f"   DPD reduced: {abs(dpd):.4f} → {abs(dpd_fair):.4f}  ({abs((dpd-dpd_fair)/dpd)*100:.1f}% improvement)")
print(f"   EOD reduced: {abs(eod):.4f} → {abs(eod_fair):.4f}  ({abs((eod-eod_fair)/eod)*100:.1f}% improvement)")

# %% [markdown]
# ## Cell 10 — Export Fairness Report

# %%
report_lines = [
    "=" * 55,
    "  TRUESIGHT AI — FAIRNESS REPORT",
    "  Google Solution Challenge 2026",
    "=" * 55,
    f"  Verdict         : {verdict}",
    "",
    "  BEFORE MITIGATION",
    f"  Disparate Impact         : {di:.4f}  (≥0.80 = fair)",
    f"  Demographic Parity Diff  : {abs(dpd):.4f}  (<0.10 = fair)",
    f"  Equalized Odds Diff      : {abs(eod):.4f}  (<0.10 = fair)",
    "",
    "  AFTER MITIGATION",
    f"  Demographic Parity Diff  : {abs(dpd_fair):.4f}",
    f"  Equalized Odds Diff      : {abs(eod_fair):.4f}",
    "",
    "  AI EXPLANATION",
    explanation[:400] + ("..." if len(explanation) > 400 else ""),
    "",
    "  RECOMMENDED ACTIONS",
    "  1. Remove gender/zip_code as direct model features",
    "  2. Apply AIF360 Reweighing during retraining",
    "  3. Enforce Equalized Odds via ThresholdOptimizer",
    "  4. Re-audit every 6 months",
    "=" * 55,
]

report_text = "\n".join(report_lines)

with open("truesight_fairness_report.txt", "w") as f:
    f.write(report_text)

print(report_text)
print("\n✅ Report saved as truesight_fairness_report.txt")

# Download in Colab
try:
    from google.colab import files
    files.download("truesight_fairness_report.txt")
    files.download("bias_mitigation_results.png")
    files.download("exploratory_analysis.png")
    print("✅ Files downloaded to your machine.")
except ImportError:
    print("(Not in Colab — files saved locally)")
